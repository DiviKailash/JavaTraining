package com.dal.exception;

import java.io.*;

public  class UserNtFoundException extends Exception {
	public UserNtFoundException() {
		System.out.println("user not found");
	}
}

